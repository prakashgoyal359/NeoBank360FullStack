# JpaRespository

![alt text](image.png)

The JpaRepository<T, ID> is an interface which extends QueryByExampleExecutor<T> and PagingAndSortingRepository<T, ID>

Then PagingAndSortingRepository<T, ID> is extends the CurdRepository<T, ID>

Then CurdRepository<T, ID> is extends the Repository<T, ID>

The **SimpleJpaRespository** Class has all the methods implemented of JpaRepository.

The SimpleJpaRespository Class internally use the **entityManager**.

entityManager do all the work related to **Hibernate**.

So to undersatnd entityManager we have to first understand the **Hibernate-Entity LifeCycle**.

## Hibernate-Entity LifeCycle

![alt text](<ChatGPT Image Jun 10, 2026, 09_20_57 PM.png>)

### 1. Transient State

Patient patient = new Patient();

📌 State: Transient

Object exists only in Java memory.
Hibernate does not know about it.
No database row exists.
No Session is managing it.

In your diagram:

Entity
|
new Patient()
|
Transient
Example
Patient patient = new Patient();
patient.setName("John");

At this point:

Java Object ✔
Database Row ✘

### 2. Persistent State

When you save the object:

session.save(patient);

or

entityManager.persist(patient);

📌 State: Persistent

Hibernate now:

Tracks the object.
Manages changes automatically.
Synchronizes with the database.

Diagram:

Transient
|
save()
persist()
update()
|
Persistent
Example
Session session = sessionFactory.openSession();

Transaction tx = session.beginTransaction();

Patient patient = new Patient();
patient.setName("John");

session.save(patient);

tx.commit();

Database:

ID Name
1 John

### 3. Automatic Update (Dirty Checking)

Once an object becomes persistent:

patient.setName("John Smith");

Hibernate detects the change automatically.

tx.commit();

Hibernate generates:

UPDATE patient
SET name='John Smith'
WHERE id=1;

You don't need:

session.update(patient);

because Hibernate is already tracking the object.

### 4. Detached State

A Persistent object becomes Detached when:

session.close();

or

session.clear();

or

session.detach(patient);

Diagram:

Persistent
|
detach()
close()
clear()
|
Detached
Example
session.close();

Now:

Java Object ✔
Database Row ✔
Hibernate Tracking ✘

Hibernate no longer monitors changes.

Detached Example
patient.setName("New Name");

No SQL runs.

Why?

Because Hibernate is not managing the object anymore.

### 5. Reattaching Detached Object

You can bring it back into Hibernate's control.

Diagram:

Detached
|
merge()
save()
lock()
|
Persistent
Example
Session session2 = sessionFactory.openSession();

session2.merge(patient);

Now Hibernate tracks it again.

State:

Detached → Persistent

### 6. Removed State

When you delete an entity:

session.delete(patient);

or

entityManager.remove(patient);

Diagram:

Persistent
|
delete()
|
Removed
Example
session.delete(patient);

Hibernate marks it for deletion.

When transaction commits:

DELETE FROM patient
WHERE id=1;

### 7. Garbage Collection

The arrows going to the dustbin indicate Garbage Collection.

If no reference exists:

patient = null;

Java's Garbage Collector removes the object from memory.

Example:

Patient patient = new Patient();
patient = null;

Eventually:

Garbage Collected

Object disappears from memory.

![alt text](image-2.png)

![alt text](image-1.png)
